from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare('E2','E8','E4','E1','E5','E7', 'E6','E3') 
u = bdd.add_expr(r'(((((((E8 \/ E7) /\ (E5 \/ E6)) \/ E4) \/ E3) \/ E2) /\ (((E8 \/ E7) /\ (E5 \/ E6)) \/ E1)))') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('rour-method.pdf', roots=[v])

