from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare('A','B', 'C', 'D', 'E', 'F') 
u = bdd.add_expr(r'((A /\ B) \/ ( C /\ ( D \/ E ) /\ F ))') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('our-method.pdf', roots=[v])

