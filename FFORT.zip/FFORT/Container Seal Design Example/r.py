from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare('A','D', 'B', 'F', 'C', 'E') 
u = bdd.add_expr(r'((A /\ B) \/ ( C /\ ( D \/ E ) /\ F ))') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('rour-method.pdf', roots=[v])

