from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare( 'B411',  'B521',  'B211','B12', 'B13', 'B23' ,  'B413',   'B512' ,'B532',   'B531' , 'B32', 'B511','B11', 'B522','B33', 'B31','B422', 'B412', 'B222' , 'B421', 'B212','B221') 
u = bdd.add_expr(r'( (B11 \/ B12 \/ B13 )\/ ((B211 \/ B212 ) \/ B23 \/ (B221 \/ B222 ) )  \/ ((B511 /\ B512 ) \/ (B521 \/ B522 ) \/ (B531 \/ B532 ) ) \/ (B31 \/ B32  \/ B33) \/ ((B411 \/ B412 \/ B413) \/ (B421 \/ B422)))') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('r.pdf', roots=[v])

