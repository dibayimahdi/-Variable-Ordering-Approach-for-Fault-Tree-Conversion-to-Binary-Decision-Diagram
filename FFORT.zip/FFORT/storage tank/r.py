from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare( 'B11',  'B211',  'B511','B31', 'B411', 'B12' ,  'B212',   'B512' ,'B32',   'B412' , 'B13', 'B23','B521', 'B33','B413', 'B221','B522', 'B421', 'B222' , 'B531', 'B422','B532') 
u = bdd.add_expr(r'( (B11 \/ B12 \/ B13 )\/ ((B211 \/ B212 ) \/ B23 \/ (B221 \/ B222 ) )  \/ ((B511 /\ B512 ) \/ (B521 \/ B522 ) \/ (B531 \/ B532 ) ) \/ (B31 \/ B32  \/ B33) \/ ((B411 \/ B412 \/ B413) \/ (B421 \/ B422)))') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('r.pdf', roots=[v])

