from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare('A', 'D','I', 'M','P', 'V','Y', 'B','E', 'J','N', 'Q','W', 'Z','C', 'F','K', 'O','R', 'X','Z1', 'G','L', 'S','H', 'T','U') 
u = bdd.add_expr(r'( ((A /\ B ) /\ C ) \/ ((D /\ E /\ F ) /\ G /\ H ) \/ ((I /\ J ) \/ (K /\ L ) ) \/ ((M \/ N ) /\ O ) \/ ((P /\ Q /\ R ) \/ (S /\ T /\ U ) ) \/ ( V /\ W /\ X) \/ (Y /\ Z /\ Z1 ) )') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('rour-method.pdf', roots=[v])

