from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare('B', 'C', 'A1', 'A2', 'A3', 'D' , 'E1' , 'E2' , 'E3' ,'F1' , 'F2', 'G1', 'G2' , 'G3' , 'H1',  'H2', 'H3', 'I1', 'I2', 'I3', 'J1', 'J2', 'K', 'L', 'M1', 'M2', 'M3', 'O', 'P', 'N1', 'N2', 'N3','Q', 'R', 'S') 
u = bdd.add_expr(r'((B \/ C \/ (A1 \/ A2 \/ A3)) \/ (D \/ (E1 \/ E2 \/ E3) \/ (F1 /\ F2 ) \/ (G1 \/ G2 \/ G3) \/ (H1 \/ H2 \/ H3) \/ (I1 \/ I2 \/ I3)) \/ ((J1 /\ J2 ) \/ K \/ L) \/ ((M1 \/ M2 \/ M3) \/ O \/ P \/ (N1 /\ N2 /\ N3 )) \/ (Q \/ R \/ S))') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('our-method.pdf', roots=[v])

