from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare('R','T','S1','K2','K1','S') 
u = bdd.add_expr(r'((T \/ ((S /\ (S1 \/ (K1 \/ R))) \/ K2)))') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('r-our-method.pdf', roots=[v])

