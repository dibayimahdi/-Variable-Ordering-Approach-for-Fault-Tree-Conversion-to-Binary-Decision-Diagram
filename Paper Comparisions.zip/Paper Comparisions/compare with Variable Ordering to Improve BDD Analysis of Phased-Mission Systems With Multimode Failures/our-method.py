from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare('A11','B11', 'C11', 'A12', 'B12', 'B32','C12','B22', 'A13', 'B13','C13','B33') 
u = bdd.add_expr(r'(     (  A11   \/ B11   \/ C11 )   \/ ( A12     \/ ( ( B12 \/B32   ) /\ C12  )  \/  B22    )   \/          (   (A13/\B13/\C13) \/ B33 )    )') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('our-method.pdf', roots=[v])

