from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare(  'a4', 'f4',  'c4', 'c1','e3',  'b3', 'd3', 'd1' ) 
u = bdd.add_expr(r'((c1 /\ d1) \/ (( b3  \/ d3)  /\ e3  )     \/ ( a4  \/  ( c4 /\ f4 )  )  )') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('Su-method.pdf', roots=[v])

