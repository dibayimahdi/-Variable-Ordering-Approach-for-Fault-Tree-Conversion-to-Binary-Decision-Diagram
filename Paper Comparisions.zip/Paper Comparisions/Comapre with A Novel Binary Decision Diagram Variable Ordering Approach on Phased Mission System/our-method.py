from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare('c1','d1', 'b3', 'd3', 'e3', 'a4','c4','f4') 
u = bdd.add_expr(r'((c1 /\ d1) \/ (( b3  \/ d3)  /\ e3  )     \/ ( a4  \/  ( c4 /\ f4 )  )  )') 
print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('our-method.pdf', roots=[v])

