from dd import autoref as _bdd 
 
bdd = _bdd.BDD() 
bdd.declare('c', 'd',  'b', 'a') 
u = bdd.add_expr(r'((c \/ a \/ d ) /\ (a \/ b) )') 

print(u.negated) 
v = ~ u 
print(v.negated) 
bdd.collect_garbage() 
num_nodes = len(bdd)
print(f"Number of nodes in the BDD: {num_nodes}")
bdd.dump('our-method2.pdf', roots=[v])

